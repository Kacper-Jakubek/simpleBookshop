package com.example.simplebookshop;

import org.springframework.stereotype.Component;

@Component
public class PersonMenager {
}
